package com.tao.seaman.common.base;

/**
 * Service接口
 * @creater tao
 * @time 2018/6/17
 */
public interface BaseService {
}
