package com.tao.seaman.common.util;

/**
 * 代码生成工具类
 * @creater tao
 * @time 2018/6/30
 */
public class MybatisGeneratorUtil {


}
