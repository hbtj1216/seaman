package com.tao.seaman.common.base;

/**
 * 系统接口
 * @creater tao
 * @time 2018/6/17
 */
public interface BaseInterface {

    /**
     * 系统初始化
     */
    void init();
}
