package com.tao.seaman.common.base;

/**
 * 全局常量类
 * @creater tao
 * @time 2018/6/17
 */
public class BaseConst {
    
}
