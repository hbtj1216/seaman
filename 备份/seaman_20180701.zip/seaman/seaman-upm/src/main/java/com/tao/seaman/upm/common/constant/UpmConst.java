package com.tao.seaman.upm.common.constant;

/**
 * @creater tao
 * @time 2018/6/18
 */
public class UpmConst {

    public static final String UPM_TYPE = "seaman.upm.type";
}
